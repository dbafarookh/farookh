<html>
<div><br/><center><h2><font face="Lucida Handwriting" size="+1" color="#00CCFF">ABOUT US</font></h2></center></div>
<div style="width:100%;float:left">
<div>
  <p><br/>
  
	  <div align="center"><img src="usepics/abt3.jpg"/></div>
	  <div>
	  <p>
	  <p>Launched in 1993, Fashion Shop created a niche in the ready to wear market in India with a premium range of clothing for all. With focus on product innovation and unique use of colors it has today come a long way since it was incepted in 1993.</p><br>

<p>The brand in no time has become the choice of the up market, trend-savvy, sophisticated and discerning Indian and changed the way he dressed. With flagship stores in the best locations and international service, Fashion Shop brought in an International shopping experience to the country. The nation saw one of the first retail brands of international quality grow, attain national acclaim. Our distribution channel spread not only all over the country but crossed borders to the Middle East; it continues to grow with each year with now over 350 shopping destinations across the country. Today, the brand is part of the Future group.</p><br>

<p>Fashion Shop has always used highest quality fabrics and product engineering techniques that give the user the unique comfort and tactile feel which no other brand offers. This is clubbed with the use of colors to give the sophisticate, yet colorful look that is unique to the Brand.</p><br>

<p>To ensure that customers get the best product from us, we have pioneered the techniques like Golf Ball Wash, Cone Dyed Casuals and Thermo-fused buttoning to name a few. These innovations have taken our collection to a whole new level, making it synonymous with the words "Luxury & Style". As a part of the initiative to reward our premium customers, ColorPlus has launched �Spectrum�, an exclusive membership to a plethora of benefits. Spectrum offers its members reward points on every purchase which can be redeemed at any of our outlets and a host of other benefits and privileges.</p><br>

<p>Thus Fashion Shop today is a complete lifestyle brand complementing every facet of your personality: be it at work, leisure or those special moments.</p></p>
	 </div>
	  </div>
	  </div>
	  </html>