<?php
$conn=mysqli_connect("localhost","root","","shop") or die(mysqli_error());
?>